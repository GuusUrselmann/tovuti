<table class="striped responsive-table table-header">
    <thead>
        <tr>
            <th></th>
            <th>Maandag</th>
            <th>Dinsdag</th>
            <th>Woensdag</th>
            <th>Donderdag</th>
            <th>Vrijdag</th>
            <th>Zaterdag</th>
            <th>Zondag</th>
        </tr>
    </thead>
    <tbody>
<?php
    $lesNamenIdsArray = GetLessonsHead($pdo);
    $lesNamen = $lesNamenIdsArray[0];
    $lesIds = $lesNamenIdsArray[1];

    $dagen = array(1, 2, 3, 4, 5, 6, 7);

    foreach ($lesIds as $lesId)
    {
        $lesNaamKey = $lesId - 1;
        echo "<tr class='hoverable'>\n"
                ."\t<th>"
                    .$lesNamen[$lesNaamKey]
                ."</th>\n";

        foreach ($dagen as $dag)
        {
            echo "\n<td>";
            GetLessonsContent($pdo, $dag, $lesId);
            echo "\n</td>";
        }
        echo "</tr>\n";
    }
?>
    </tbody>
</table>
