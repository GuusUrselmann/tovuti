<!DOCTYPE html>
<html lang="nl">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Just Be Fit</title>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>


</head>
<body>
  <nav class="white" role="navigation" id="nav">
    <ul id="dropdown1" class="dropdown-content">
      <li><a href="about.php?les=Ouderenfit">Ouderenfit</a></li>
      <li><a href="about.php?les=Bedrijfsfitness">Bedrijfsfitness</a></li>
      <li><a href="about.php?les=Cardiotraining">Cardiotraining</a></li>
      <li><a href="about.php?les=SpierversterkendeTraining">Spierversterkende Training</a></li>
      <li><a href="about.php?les=20MinutenFitProgramma">20 Minuten Fit Programma</a></li>
      <li><a href="about.php?les=SlankerEnFit">Slanker en Fit in 12 Weken</a></li>
      <!-- <li class="divider"></li> -->

    </ul>

    <ul id="dropdown2" class="dropdown-content" style="margin-left: 50px;">
      <li><a href="about.php?les=Zumba">Zumba</a></li>
      <li><a href="about.php?les=Hardlopen">Hardlopen</a></li>
      <li><a href="about.php?les=Bootcamp">Bootcamp</a></li>
      <li><a href="about.php?les=Spinning">Spinning</a></li>
      <li><a href="about.php?les=Pilates">Pilates</a></li>
      <li><a href="about.php?les=Piloxing">Piloxing</a></li>
      <li><a href="about.php?les=NirvanaFitness">Nirvana Fitness</a></li>
      <li><a href="about.php?les=BoksFit">Boksfit</a></li>
      <li><a href="about.php?les=Powerboxing">Powerboxing</a></li>
    </ul>

    <div class="nav-wrapper container">
      <a id="logo-container" href="index.php" class="brand-logo">
        <img class="image-height" src="images/JustBeFitLogo.jpg"/>
      </a>
      <ul class="right hide-on-med-and-down">
        <li id="aanbodLi" class="dropdown-button" data-activates="dropdown1"><a href="#aanbod">Aanbod</a></li>
        <li><a href="#tarieven">Tarieven</a></li>
        <li><a href="#openingstijden">Openingstijden</a></li>
        <li><a href="#overmij">Over Mij</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="#aanbod">Aanbod</a></li>
        <li><a href="#tarieven">Tarieven</a></li>
        <li><a href="#openingstijden">Openingstijden</a></li>
        <li><a href="#overmij">Over Mij</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons orange-text">menu</i></a>
    </div>
  </nav>

  <div id="index-banner" class="parallax-container small-bigger">
    <div class="section">
      <div class="container">

        <div class="row">
          <div class="col s12">
            <h1 class="header orange-text">Just Be Fit</h1>
          </div>
        </div>

        <div class="row">
          <div class="col s12">
            <h5 class="header light">Huiselijke sfeer</h5><br>
            <h5 class="header light">Voordelige tarieven</h5><br>
            <h5 class="header light">Diverse trainingsvormen & groepslessen</h5><br>
            <h5 class="header light">Samenwerking met fysiotherapeut</h5><br>
            <h5 class="header light">Intensieve en persoonlijke begeleiding</h5><br>
            <a href="#aanbod" id="download-button" class="btn-large waves-effect waves-light orange">Ontdek meer</a>
          </div>
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="images/home_background2.jpg" alt="Unsplashed background img 1"></div>
  </div>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <script src="js/slider.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      $('.dropdown-button').dropdown({
        hover: true,
        belowOrigin: true,
        constrain_width: false,
      });
    });
  </script>
  </body>
</html>
